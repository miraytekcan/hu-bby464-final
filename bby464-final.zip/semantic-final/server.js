const express = require("express");
const axios = require("axios");
const cors = require("cors");
const app = express();
app.use(cors());
const clientId = "b3c7842cd4774de3bee31f3107880dbf";
const clientSecret = "f4ec8089d5fd4fc98ee0e1054cbbdb1c";
let accessToken = "";
let expiresAt = 0;
async function refreshToken() {
  const headers = {
    Authorization: "Basic " + Buffer.from(clientId + ":" + clientSecret).toString("base64"),
    "Content-Type": "application/x-www-form-urlencoded",
  };
  const body = new URLSearchParams({
    grant_type: "client_credentials",
  });
  const res = await axios.post("https://accounts.spotify.com/api/token", body, { headers });
  accessToken = res.data.access_token;
  expiresAt = Date.now() + res.data.expires_in * 1000;
}
app.get("/spotify-token", async (req, res) => {
  if (!accessToken || Date.now() >= expiresAt) {
    await refreshToken();
  }
  res.json({ access_token: accessToken });
});
app.get("/search", async (req, res) => {
  const q = req.query.q;
  if (!q) return res.status(400).send("Query param missing");
  try {
    if (!accessToken || Date.now() >= expiresAt) {
      await refreshToken();
    }
    const headers = { Authorization: `Bearer ${accessToken}` };
    const spotifyRes = await axios.get("https://api.spotify.com/v1/search", {
      headers,
      params: { q, type: "track", limit: 1 },
    });
    const items = spotifyRes.data.tracks.items;
    if (items.length === 0) {
      return res.status(404).send("No track found");
    }
    const track = items[0];
    let lyrics = "Lyrics not found.";
    try {
      const lyricsRes = await axios.get(`https://api.lyrics.ovh/v1/${track.artists[0].name}/${track.name}`);
      lyrics = lyricsRes.data.lyrics || lyrics;
    } catch (err) {
      console.warn("Lyrics API failed:", err.message);
    }
    res.json({
      name: track.name,
      artist: track.artists.map(a => a.name).join(", "),
      album: track.album.name,
      release_date: track.album.release_date,
      image: track.album.images[0]?.url || "",
      preview_url: track.preview_url || "",
      lyrics
    });
  } catch (err) {
    console.error("Error in /search:", err.message);
    res.status(500).send("Internal Server Error");
  }
});
app.get("/", (req, res) => {
  res.send("Backend is working!");
});
app.listen(3001, () => {
  console.log("Backend is running at http://localhost:3001");
});