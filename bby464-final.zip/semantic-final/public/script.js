async function searchSpotify() {
  const query = document.getElementById("searchInput").value;
  const res = await fetch(`http://localhost:3001/search?q=${encodeURIComponent(query)}`);
  if (!res.ok) {
    document.getElementById("results").innerHTML = "Song not found.";
    d3.select("#graph").html(""); 
    return;
  }
  const data = await res.json();
  document.getElementById("results").innerHTML = "";
  data.forEach((trackData, index) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${trackData.image}" width="100">
      <h3>${trackData.name}</h3>
      <p><strong>Artist:</strong> ${trackData.artist}</p>
      <p><strong>Album:</strong> ${trackData.album}</p>
      <p><strong>Release Date:</strong> ${trackData.release_date}</p>
      <p><strong>Genre:</strong> ${trackData.genres || 'Unknown'}</p>
      <p><strong>Duration:</strong> ${(trackData.duration_ms / 1000).toFixed(0)} sec</p>
      <p><strong>Popularity:</strong> ${trackData.popularity}</p>
      <audio controls src="${trackData.preview_url}"></audio>
      <pre><strong>Lyrics:</strong>\n${trackData.lyrics}</pre>
    `;
    document.getElementById("results").appendChild(card);
    if (index === 0) drawGraph(trackData); 
  });
}
function drawGraph(songData) {
  const nodes = [
    { id: songData.name, group: "Song" },
    { id: songData.artist, group: "Artist" },
    { id: songData.album, group: "Album" },
    { id: songData.release_date, group: "Date" },
    { id: songData.genres || "Unknown", group: "Genre" },
    { id: `${(songData.duration_ms / 1000).toFixed(0)} sec`, group: "Duration" },
    { id: `Popularity: ${songData.popularity}`, group: "Popularity" }
  ];

  const links = [
    { source: songData.name, target: songData.artist },
    { source: songData.artist, target: songData.album },
    { source: songData.album, target: songData.release_date },
    { source: songData.name, target: songData.genres || "Unknown" },
    { source: songData.name, target: `${(songData.duration_ms / 1000).toFixed(0)} sec` },
    { source: songData.name, target: `Popularity: ${songData.popularity}` }
  ];
  const width = 600, height = 400;
  d3.select("#graph").html(""); // eski grafik varsa temizle
  const svg = d3.select("#graph").append("svg")
    .attr("width", width)
    .attr("height", height);
  const simulation = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(100))
    .force("charge", d3.forceManyBody().strength(-300))
    .force("center", d3.forceCenter(width / 2, height / 2));
  const link = svg.append("g").selectAll("line")
    .data(links).enter().append("line")
    .attr("stroke-width", 2)
    .attr("stroke", "#aaa");
  const node = svg.append("g").selectAll("circle")
    .data(nodes).enter().append("circle")
    .attr("r", 15)
    .attr("fill", d => {
      if (d.group === "Song") return "#66c2a5";
      if (d.group === "Artist") return "#fc8d62";
      return "#8da0cb";
    })
    .call(d3.drag()
      .on("start", event => {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
      })
      .on("drag", event => {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
      })
      .on("end", event => {
        if (!event.active) simulation.alphaTarget(0);
        event.subject.fx = null;
        event.subject.fy = null;
      })
    );
  const label = svg.append("g").selectAll("text")
    .data(nodes).enter().append("text")
    .text(d => d.id)
    .attr("x", 8)
    .attr("y", 3);
  simulation.on("tick", () => {
    link.attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);
    node.attr("cx", d => d.x).attr("cy", d => d.y);
    label.attr("x", d => d.x + 10).attr("y", d => d.y);
  });
}