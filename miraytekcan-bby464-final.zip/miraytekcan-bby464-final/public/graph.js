const RDF  = $rdf.Namespace('http://www.w3.org/1999/02/22-rdf-syntax-ns#');
const OWL  = $rdf.Namespace('http://www.w3.org/2002/07/owl#');
const RDFS = $rdf.Namespace('http://www.w3.org/2000/01/rdf-schema#');
const NS   = $rdf.Namespace('urn:webprotege:ontology:9bba460b-3834-41dd-b10b-6d25066b2670#');
const store = $rdf.graph();
const TYPE_MAP = {}, PROPERTY_MAP = {};
const DESIRED_TYPES = ['Song'];
document.getElementById('fileInput').addEventListener('change', function () {
  const file = this.files[0];
  const reader = new FileReader();
  reader.onload = function (e) {
    store.statements = [];
    $rdf.parse(e.target.result, store, NS().value, file.name.endsWith('.ttl') ? 'text/turtle' : 'application/rdf+xml');
    buildTypeMap();
    buildPropertyMap();
    document.getElementById('typeSelect').disabled = false;
    document.getElementById('instanceSelect').disabled = false;
    populateTypeSelect();
    document.getElementById('info').textContent = 'Ontology loaded.';
  };
  reader.readAsText(file);
});
function buildTypeMap() {
  store.each(undefined, RDF('type'), OWL('Class')).forEach(c => {
    const label = store.any(c, RDFS('label'), undefined)?.value || c.value.split(/[#\/]/).pop();
    if (DESIRED_TYPES.includes(label)) TYPE_MAP[label] = c;
  });
}
function buildPropertyMap() {
  store.each(undefined, RDF('type'), OWL('ObjectProperty')).forEach(p => {
    const label = store.any(p, RDFS('label'), undefined)?.value;
    if (label && ['hasProducer', 'hasSongwriter', 'belongsToAlbum', 'hasCollaborator'].includes(label)) {
      PROPERTY_MAP[label] = p;
    }
  });
}
function populateTypeSelect() {
  const ts = document.getElementById('typeSelect');
  ts.innerHTML = '';
  Object.keys(TYPE_MAP).forEach(name => ts.add(new Option(name, name)));
  ts.onchange = loadInstances;
  loadInstances();
}
function loadInstances() {
  const type = document.getElementById('typeSelect').value;
  const cls = TYPE_MAP[type];
  const inds = store.each(undefined, RDF('type'), cls);
  const isel = document.getElementById('instanceSelect');
  isel.innerHTML = '';
  inds.forEach(i => {
    const label = store.any(i, RDFS('label'), undefined)?.value || i.value.split(/[#\/]/).pop();
    isel.add(new Option(label, i.value));
  });
  isel.onchange = () => showDetails(type);
  showDetails(type);
}
function showDetails(type) {
  const uri = document.getElementById('instanceSelect').value;
  const subj = $rdf.sym(uri);
  const label = store.any(subj, RDFS('label'), undefined)?.value || uri.split(/[#\/]/).pop();
  document.getElementById('details').innerHTML = `<h2>${label}</h2>`;
  if (type === 'Song') searchSpotify(label);
}
async function searchSpotify(query) {
  query = query || document.getElementById("searchInput").value;
  document.getElementById("searchInput").value = query;
  try {
    const res = await fetch(`http://localhost:3001/search?q=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error("Spotify fetch failed");

    const data = await res.json();
    document.getElementById("results").innerHTML = `
      <div class="card">
        <img src="${data.image}" width="100">
        <h3>${data.name}</h3>
        <p><strong>Artist:</strong> ${data.artist}</p>
        <p><strong>Album:</strong> ${data.album}</p>
        <p><strong>Release Date:</strong> ${data.release_date}</p>
        ${data.preview_url ? `<audio controls src="${data.preview_url}"></audio>` : ""}
        <pre><strong>Lyrics:</strong>\n${data.lyrics}</pre>
      </div>`;
    drawGraph(data);
  } catch (e) {
    console.warn("Spotify failed. Using Google Knowledge Graph instead.");
    searchGoogleKG(query);
  }
}
async function searchGoogleKG(query) {
  const apiKey = 'AIzaSyCkGdGNPG_kZtusaDwOwnr1gkDhn0HA_Gc'; 
  const endpoint = `https://kgsearch.googleapis.com/v1/entities:search?query=${encodeURIComponent(query)}&limit=1&indent=true&key=${apiKey}`;
  try {
    const res = await fetch(endpoint);
    const data = await res.json();
    if (!data.itemListElement.length) {
      document.getElementById("results").innerHTML = "No results from Google Knowledge Graph.";
      return;
    }
    const result = data.itemListElement[0].result;
    const songData = {
      name: result.name || "Unknown",
      artist: result.description || "Unknown Artist",
      album: "Google KG Entity",
      release_date: result.detailedDescription?.articleBody?.slice(0, 100) || "No detailed info"
    };
    document.getElementById("results").innerHTML = `
      <div class="card">
        <h3>${songData.name}</h3>
        <p><strong>Type:</strong> ${result['@type']?.join(', ')}</p>
        <p><strong>Description:</strong> ${songData.artist}</p>
        <p><strong>More Info:</strong> <a href="${result.detailedDescription?.url || '#'}" target="_blank">Wikipedia</a></p>
      </div>`;
    drawGraph(songData);
  } catch (error) {
    document.getElementById("results").innerHTML = "Error fetching from Google KG.";
    console.error(error);
  }
}
function drawGraph(data) {
  const nodes = [
    { id: data.name, group: "Song" },
    { id: data.artist, group: "Artist" },
    { id: data.album, group: "Album" },
    { id: data.release_date, group: "Date" }
  ];
  const links = [
    { source: data.name, target: data.artist },
    { source: data.artist, target: data.album },
    { source: data.album, target: data.release_date }
  ];
  d3.select("#graph").html("");
  const svg = d3.select("#graph").append("svg")
    .attr("width", 600).attr("height", 400);
  const simulation = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(100))
    .force("charge", d3.forceManyBody().strength(-200))
    .force("center", d3.forceCenter(300, 200));
  svg.append("g").selectAll("line")
    .data(links).enter().append("line")
    .attr("stroke-width", 2).attr("stroke", "#999");
  const node = svg.append("g").selectAll("circle")
    .data(nodes).enter().append("circle")
    .attr("r", 12)
    .attr("fill", d => d.group === "Song" ? "#66c2a5" : "#fc8d62")
    .call(d3.drag()
      .on("start", event => { if (!event.active) simulation.alphaTarget(0.3).restart(); event.subject.fx = event.subject.x; event.subject.fy = event.subject.y; })
      .on("drag", event => { event.subject.fx = event.x; event.subject.fy = event.y; })
      .on("end", event => { if (!event.active) simulation.alphaTarget(0); event.subject.fx = null; event.subject.fy = null; })
    );
  svg.append("g").selectAll("text")
    .data(nodes).enter().append("text")
    .text(d => d.id).attr("x", 8).attr("y", 3);

  simulation.on("tick", () => {
    svg.selectAll("line")
      .attr("x1", d => d.source.x).attr("y1", d => d.source.y)
      .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
    svg.selectAll("circle")
      .attr("cx", d => d.x).attr("cy", d => d.y);
    svg.selectAll("text")
      .attr("x", d => d.x + 12).attr("y", d => d.y);
  });
}